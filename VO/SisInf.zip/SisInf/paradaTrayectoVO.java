public class paradaTrayectoVO {
    private int paradaAutobus;
    private int linea;
    private int orden;

    public paradaTrayectoVO(int parada) {
        
    }
}
