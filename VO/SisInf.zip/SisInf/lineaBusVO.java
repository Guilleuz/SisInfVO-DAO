public class lineaBusVO {
    
}
